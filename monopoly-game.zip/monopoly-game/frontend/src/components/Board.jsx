// Board.jsx
// Renders the 40-tile board as an 11x11 CSS grid (corners + 9 tiles per
// side), with player tokens positioned absolutely and animated via CSS
// transitions whenever a player's tile index changes - this is what gives
// the "sliding" movement effect without any imperative animation code.

import { BOARD, GROUP_COLORS, TILE_TYPES, tileGridPosition } from '../boardData';

function ownerColor(tileId, properties, players) {
  const p = properties[tileId];
  if (!p?.ownerId) return null;
  const owner = players.find((pl) => pl.id === p.ownerId);
  return owner?.color || null;
}

function HouseIndicator({ houses }) {
  if (!houses) return null;
  if (houses === 5) {
    return (
      <div className="absolute left-1/2 top-0.5 -translate-x-1/2 rounded-sm bg-rent px-1 text-[8px] font-bold text-white shadow-sm">
        HOTEL
      </div>
    );
  }
  return (
    <div className="absolute left-1/2 top-0.5 flex -translate-x-1/2 gap-0.5">
      {Array.from({ length: houses }).map((_, i) => (
        <span key={i} className="h-1.5 w-1.5 rounded-[1px] bg-go shadow-sm" />
      ))}
    </div>
  );
}

function PropertyTile({ tile, properties, players, orientation, onSelect }) {
  const propState = properties[tile.id];
  const owner = propState?.ownerId ? players.find((p) => p.id === propState.ownerId) : null;
  const groupColor = GROUP_COLORS[tile.group];

  const barClasses = {
    bottom: 'order-2 h-2.5 w-full',
    top: 'order-0 h-2.5 w-full',
    left: 'order-0 h-full w-2.5',
    right: 'order-2 h-full w-2.5',
  }[orientation];

  const isVertical = orientation === 'left' || orientation === 'right';

  return (
    <button
      type="button"
      onClick={() => onSelect?.(tile.id)}
      className={`group relative flex ${isVertical ? 'flex-row' : 'flex-col'} h-full w-full overflow-hidden border border-board-line/70 bg-board-tile text-left transition-colors hover:bg-brass/10`}
    >
      <div className={barClasses} style={{ backgroundColor: groupColor }} />
      <div className="order-1 flex flex-1 flex-col items-center justify-center gap-0.5 p-0.5 text-center">
        <p className="line-clamp-2 text-[6.5px] font-semibold leading-tight text-ink sm:text-[7.5px]">
          {tile.name}
        </p>
        <p className="text-[6px] font-medium text-ink-faint sm:text-[7px]">${tile.price}</p>
        {propState?.mortgaged && (
          <span className="rounded-sm bg-ink/70 px-1 text-[6px] font-bold text-white">MTG</span>
        )}
      </div>
      <HouseIndicator houses={propState?.houses} />
      {owner && (
        <span
          className="absolute bottom-0.5 right-0.5 h-2 w-2 rounded-full ring-1 ring-white/70"
          style={{ backgroundColor: owner.color }}
        />
      )}
    </button>
  );
}

function RailroadTile({ tile, properties, players, onSelect }) {
  const propState = properties[tile.id];
  const owner = propState?.ownerId ? players.find((p) => p.id === propState.ownerId) : null;
  return (
    <button
      type="button"
      onClick={() => onSelect?.(tile.id)}
      className="relative flex h-full w-full flex-col items-center justify-center gap-0.5 border border-board-line/70 bg-board-tile p-0.5 text-center transition-colors hover:bg-brass/10"
    >
      <svg viewBox="0 0 24 24" className="h-3 w-3 text-ink-soft sm:h-3.5 sm:w-3.5" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M4 17h16M6 17V7a2 2 0 012-2h8a2 2 0 012 2v10M8 21l-2-4M16 21l2-4" />
        <circle cx="8.5" cy="14" r="1" fill="currentColor" />
        <circle cx="15.5" cy="14" r="1" fill="currentColor" />
      </svg>
      <p className="line-clamp-2 text-[6.5px] font-semibold leading-tight text-ink sm:text-[7.5px]">{tile.name}</p>
      <p className="text-[6px] font-medium text-ink-faint sm:text-[7px]">${tile.price}</p>
      {owner && (
        <span className="absolute bottom-0.5 right-0.5 h-2 w-2 rounded-full ring-1 ring-white/70" style={{ backgroundColor: owner.color }} />
      )}
    </button>
  );
}

function UtilityTile({ tile, properties, players, onSelect }) {
  const propState = properties[tile.id];
  const owner = propState?.ownerId ? players.find((p) => p.id === propState.ownerId) : null;
  const isPower = tile.name.includes('Power');
  return (
    <button
      type="button"
      onClick={() => onSelect?.(tile.id)}
      className="relative flex h-full w-full flex-col items-center justify-center gap-0.5 border border-board-line/70 bg-board-tile p-0.5 text-center transition-colors hover:bg-brass/10"
    >
      {isPower ? (
        <svg viewBox="0 0 24 24" className="h-3 w-3 text-brass-deep sm:h-3.5 sm:w-3.5" fill="currentColor">
          <path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z" />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" className="h-3 w-3 text-blue-600 sm:h-3.5 sm:w-3.5" fill="currentColor">
          <path d="M12 2C8 8 5 11.5 5 15a7 7 0 0014 0c0-3.5-3-7-7-13z" />
        </svg>
      )}
      <p className="line-clamp-2 text-[6.5px] font-semibold leading-tight text-ink sm:text-[7.5px]">{tile.name}</p>
      <p className="text-[6px] font-medium text-ink-faint sm:text-[7px]">${tile.price}</p>
      {owner && (
        <span className="absolute bottom-0.5 right-0.5 h-2 w-2 rounded-full ring-1 ring-white/70" style={{ backgroundColor: owner.color }} />
      )}
    </button>
  );
}

function SpecialTile({ tile }) {
  const icons = {
    [TILE_TYPES.GO]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-go sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M5 12h14M13 6l6 6-6 6" />
      </svg>
    ),
    [TILE_TYPES.JAIL]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-rent sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="4" y="4" width="16" height="16" rx="1" />
        <path d="M9 4v16M15 4v16M4 9h16M4 15h16" strokeOpacity="0.5" />
      </svg>
    ),
    [TILE_TYPES.FREE_PARKING]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-brass-deep sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="12" cy="12" r="9" />
        <path d="M10 16V8h3a2.5 2.5 0 010 5h-3" />
      </svg>
    ),
    [TILE_TYPES.GO_TO_JAIL]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-rent sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M12 3l3 5.5-1 8.5H10l-1-8.5L12 3z" />
        <path d="M7 21h10" />
      </svg>
    ),
    [TILE_TYPES.CHANCE]: (
      <span className="font-display text-lg font-bold text-brass sm:text-xl">?</span>
    ),
    [TILE_TYPES.CHEST]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-go sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="3" y="9" width="18" height="11" rx="1" />
        <path d="M3 9l2-5h14l2 5M12 13v4M9 13h6" />
      </svg>
    ),
    [TILE_TYPES.TAX]: (
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-ink-soft sm:h-6 sm:w-6" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M12 2v20M17 6H9.5a2.5 2.5 0 000 5H14a2.5 2.5 0 010 5H7" />
      </svg>
    ),
  };
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-0.5 border border-board-line/70 bg-board-tile p-1 text-center">
      {icons[tile.type]}
      <p className="line-clamp-2 text-[6.5px] font-semibold leading-tight text-ink sm:text-[7.5px]">{tile.name}</p>
      {tile.amount && <p className="text-[6px] font-medium text-ink-faint sm:text-[7px]">${tile.amount}</p>}
    </div>
  );
}

function TileRenderer({ tile, properties, players, onSelect }) {
  const pos = tileGridPosition(tile.id);
  const orientation = pos.row === 11 ? 'bottom' : pos.row === 1 ? 'top' : pos.col === 1 ? 'left' : 'right';

  if (tile.type === TILE_TYPES.PROPERTY) {
    return <PropertyTile tile={tile} properties={properties} players={players} orientation={orientation} onSelect={onSelect} />;
  }
  if (tile.type === TILE_TYPES.RAILROAD) {
    return <RailroadTile tile={tile} properties={properties} players={players} onSelect={onSelect} />;
  }
  if (tile.type === TILE_TYPES.UTILITY) {
    return <UtilityTile tile={tile} properties={properties} players={players} onSelect={onSelect} />;
  }
  return <SpecialTile tile={tile} />;
}

// Position tokens within a tile: if multiple players share a tile, arrange
// them in a small cluster so they don't fully overlap.
function tokenOffset(indexInStack, totalOnTile) {
  if (totalOnTile <= 1) return { x: 0, y: 0 };
  const positions = [
    [-9, -9], [9, -9], [-9, 9], [9, 9], [0, -9], [0, 9], [-9, 0], [9, 0], [0, 0], [4, 4],
  ];
  return { x: positions[indexInStack]?.[0] ?? 0, y: positions[indexInStack]?.[1] ?? 0 };
}

function PlayerTokens({ players }) {
  const active = players.filter((p) => !p.bankrupt);
  return (
    <>
      {active.map((player) => {
        const pos = tileGridPosition(player.position);
        const sameTilePlayers = active.filter((p) => p.position === player.position);
        const indexInStack = sameTilePlayers.findIndex((p) => p.id === player.id);
        const offset = tokenOffset(indexInStack, sameTilePlayers.length);
        return (
          <div
            key={player.id}
            className="pointer-events-none absolute z-20 transition-all duration-700 ease-[cubic-bezier(0.34,1.56,0.64,1)]"
            style={{
              gridRow: pos.row,
              gridColumn: pos.col,
              transform: `translate(${offset.x}px, ${offset.y}px)`,
              justifySelf: 'center',
              alignSelf: 'center',
            }}
          >
            <span
              className="block h-3.5 w-3.5 rounded-full ring-2 ring-white shadow-token sm:h-4 sm:w-4"
              style={{ backgroundColor: player.color }}
              title={player.nickname}
            />
          </div>
        );
      })}
    </>
  );
}

export default function Board({ gameState, onSelectTile }) {
  const { properties, players, freeParkingPot } = gameState;

  return (
    <div className="relative mx-auto aspect-square w-full max-w-[720px] rounded-2xl bg-board p-2 shadow-panel sm:p-3">
      <div
        className="relative grid h-full w-full"
        style={{
          gridTemplateColumns: 'repeat(11, 1fr)',
          gridTemplateRows: 'repeat(11, 1fr)',
        }}
      >
        {BOARD.map((tile) => {
          const pos = tileGridPosition(tile.id);
          return (
            <div key={tile.id} style={{ gridRow: pos.row, gridColumn: pos.col }} className="relative">
              <TileRenderer tile={tile} properties={properties} players={players} onSelect={onSelectTile} />
            </div>
          );
        })}

        <PlayerTokens players={players} />

        {/* Center area: logo + free parking pot */}
        <div
          className="pointer-events-none flex flex-col items-center justify-center gap-2 rounded-xl"
          style={{ gridRow: '2 / 11', gridColumn: '2 / 11' }}
        >
          <p className="font-display text-3xl font-bold tracking-tight text-ink/10 sm:text-5xl">LANDMARK</p>
          {freeParkingPot > 0 && (
            <div className="rounded-full border-2 border-dashed border-brass/50 bg-brass/10 px-4 py-1.5">
              <p className="text-xs font-medium text-brass-deep">
                Free Parking pot: <span className="font-display font-bold">${freeParkingPot}</span>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
