// Lobby.jsx
// Handles three sub-states:
//  1. Landing: no room yet -> choose create or join
//  2. Waiting room: in a room, phase === 'LOBBY' -> show players, host can start
//  3. (Game itself is handled by GameUI once phase !== 'LOBBY')

import { useState } from 'react';

function PlayerSlot({ player, isMe }) {
  return (
    <div
      className={`flex items-center gap-3 rounded-xl border px-4 py-3 transition-colors ${
        isMe ? 'border-brass bg-brass/10' : 'border-board-line bg-board-tile'
      }`}
    >
      <span
        className="h-8 w-8 shrink-0 rounded-full shadow-token ring-2 ring-white/50"
        style={{ backgroundColor: player.color }}
        aria-hidden="true"
      />
      <div className="min-w-0 flex-1">
        <p className="truncate font-semibold text-ink">
          {player.nickname}
          {isMe && <span className="ml-1.5 text-xs font-normal text-ink-faint">(you)</span>}
        </p>
        <p className="text-xs text-ink-faint">
          {player.isHost ? 'Host' : 'Player'}
          {!player.connected && ' · offline'}
        </p>
      </div>
      {player.isHost && (
        <span className="rounded-full bg-brass px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink">
          Host
        </span>
      )}
    </div>
  );
}

function EmptySlot({ index }) {
  return (
    <div
      key={index}
      className="flex items-center gap-3 rounded-xl border border-dashed border-board-line/70 px-4 py-3 text-ink-faint"
    >
      <span className="h-8 w-8 shrink-0 rounded-full border-2 border-dashed border-board-line/70" />
      <p className="text-sm italic">Waiting for player…</p>
    </div>
  );
}

function LandingScreen({ onCreate, onJoin, joining, savedNickname }) {
  const urlRoomCode = new URLSearchParams(window.location.search).get('room');
  const [mode, setMode] = useState(urlRoomCode ? 'join' : null);
  const [nickname, setNickname] = useState(savedNickname);
  const [roomCode, setRoomCode] = useState(urlRoomCode ? urlRoomCode.toUpperCase() : '');
  const [error, setError] = useState('');

  const submitCreate = async (e) => {
    e.preventDefault();
    setError('');
    if (!nickname.trim()) return setError('Enter a nickname first.');
    try {
      await onCreate(nickname.trim());
    } catch (err) {
      setError(err.message);
    }
  };

  const submitJoin = async (e) => {
    e.preventDefault();
    setError('');
    if (!nickname.trim()) return setError('Enter a nickname first.');
    if (!roomCode.trim()) return setError('Enter a room code.');
    try {
      await onJoin(roomCode.trim().toUpperCase(), nickname.trim());
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-6 py-12">
      <div className="mb-10 text-center">
        <div className="mb-3 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-brass shadow-panel">
          <svg viewBox="0 0 24 24" className="h-9 w-9 text-ink" fill="none" stroke="currentColor" strokeWidth="1.8">
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <path d="M3 9h18M3 15h18M9 3v18M15 3v18" strokeOpacity="0.5" />
          </svg>
        </div>
        <h1 className="font-display text-4xl font-semibold tracking-tight text-board">Landmark</h1>
        <p className="mt-1.5 text-sm text-board/70">Trade properties. Build an empire. Bankrupt your friends.</p>
      </div>

      <div className="w-full rounded-2xl bg-board p-6 shadow-panel">
        {!mode && (
          <div className="flex flex-col gap-3">
            <button
              type="button"
              onClick={() => setMode('create')}
              className="rounded-xl bg-brass px-5 py-3.5 font-semibold text-ink shadow-tile transition-transform hover:brightness-105 active:scale-[0.98]"
            >
              Host a new game
            </button>
            <button
              type="button"
              onClick={() => setMode('join')}
              className="rounded-xl border-2 border-ink/15 px-5 py-3.5 font-semibold text-ink transition-colors hover:border-brass hover:bg-brass/5 active:scale-[0.98]"
            >
              Join with a code
            </button>
          </div>
        )}

        {mode === 'create' && (
          <form onSubmit={submitCreate} className="flex flex-col gap-4">
            <button type="button" onClick={() => setMode(null)} className="self-start text-sm text-ink-faint hover:text-ink">
              ← Back
            </button>
            <div>
              <label htmlFor="nickname-create" className="mb-1.5 block text-sm font-medium text-ink-soft">
                Your nickname
              </label>
              <input
                id="nickname-create"
                autoFocus
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                maxLength={20}
                placeholder="e.g. Sasha"
                className="w-full rounded-lg border border-board-line bg-board-tile px-3.5 py-2.5 text-ink placeholder:text-ink-faint focus:border-brass"
              />
            </div>
            {error && <p className="text-sm text-rent">{error}</p>}
            <button
              type="submit"
              disabled={joining}
              className="rounded-xl bg-brass px-5 py-3 font-semibold text-ink shadow-tile transition-transform hover:brightness-105 active:scale-[0.98] disabled:opacity-60"
            >
              {joining ? 'Creating room…' : 'Create room'}
            </button>
            <p className="text-center text-xs text-ink-faint">
              You'll get a room code to share with up to 9 friends.
            </p>
          </form>
        )}

        {mode === 'join' && (
          <form onSubmit={submitJoin} className="flex flex-col gap-4">
            <button type="button" onClick={() => setMode(null)} className="self-start text-sm text-ink-faint hover:text-ink">
              ← Back
            </button>
            <div>
              <label htmlFor="nickname-join" className="mb-1.5 block text-sm font-medium text-ink-soft">
                Your nickname
              </label>
              <input
                id="nickname-join"
                autoFocus
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                maxLength={20}
                placeholder="e.g. Sasha"
                className="w-full rounded-lg border border-board-line bg-board-tile px-3.5 py-2.5 text-ink placeholder:text-ink-faint focus:border-brass"
              />
            </div>
            <div>
              <label htmlFor="room-code" className="mb-1.5 block text-sm font-medium text-ink-soft">
                Room code
              </label>
              <input
                id="room-code"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                maxLength={5}
                placeholder="e.g. K7QXM"
                className="w-full rounded-lg border border-board-line bg-board-tile px-3.5 py-2.5 font-mono text-lg uppercase tracking-[0.3em] text-ink placeholder:tracking-normal placeholder:text-ink-faint focus:border-brass"
              />
            </div>
            {error && <p className="text-sm text-rent">{error}</p>}
            <button
              type="submit"
              disabled={joining}
              className="rounded-xl bg-brass px-5 py-3 font-semibold text-ink shadow-tile transition-transform hover:brightness-105 active:scale-[0.98] disabled:opacity-60"
            >
              {joining ? 'Joining…' : 'Join room'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

function WaitingRoom({ gameState, playerId, onStart, onLeave, roomCode }) {
  const [copied, setCopied] = useState(false);
  const me = gameState.players.find((p) => p.id === playerId);
  const isHost = me?.isHost;
  const emptySlots = Math.max(0, 10 - gameState.players.length);
  const canStart = gameState.players.length >= 2;

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(roomCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard not available, ignore */
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}?room=${roomCode}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard not available, ignore */
    }
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center px-6 py-12">
      <div className="mb-6 text-center">
        <p className="mb-1 text-sm font-medium uppercase tracking-wide text-board/60">Room code</p>
        <div className="flex items-center justify-center gap-3">
          <p className="font-mono text-5xl font-bold tracking-[0.2em] text-board">{roomCode}</p>
          <button
            type="button"
            onClick={copyCode}
            className="rounded-lg border border-board/25 px-3 py-2 text-sm text-board/80 transition-colors hover:bg-board/10"
          >
            {copied ? 'Copied ✓' : 'Copy'}
          </button>
        </div>
        <button type="button" onClick={copyLink} className="mt-2 text-sm text-brass-light underline underline-offset-2 hover:text-brass">
          Copy invite link instead
        </button>
      </div>

      <div className="rounded-2xl bg-board p-6 shadow-panel">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold text-ink">
            Players ({gameState.players.length}/10)
          </h2>
          <button type="button" onClick={onLeave} className="text-sm text-ink-faint hover:text-rent">
            Leave
          </button>
        </div>

        <div className="grid max-h-[45vh] grid-cols-1 gap-2.5 overflow-y-auto scrollbar-thin sm:grid-cols-2">
          {gameState.players.map((p) => (
            <PlayerSlot key={p.id} player={p} isMe={p.id === playerId} />
          ))}
          {Array.from({ length: Math.min(emptySlots, 10 - gameState.players.length) }).map((_, i) => (
            <EmptySlot key={i} index={i} />
          ))}
        </div>

        <div className="mt-6">
          {isHost ? (
            <>
              <button
                type="button"
                onClick={onStart}
                disabled={!canStart}
                className="w-full rounded-xl bg-brass px-5 py-3.5 font-semibold text-ink shadow-tile transition-transform hover:brightness-105 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {canStart ? 'Start game' : 'Need at least 2 players'}
              </button>
              <p className="mt-2 text-center text-xs text-ink-faint">
                Only you (the host) can start the game.
              </p>
            </>
          ) : (
            <p className="text-center text-sm text-ink-faint">
              Waiting for the host to start the game…
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Lobby({ gameState, playerId, roomCode, onCreate, onJoin, onStart, onLeave, joining, savedNickname }) {
  if (!gameState || !roomCode) {
    return <LandingScreen onCreate={onCreate} onJoin={onJoin} joining={joining} savedNickname={savedNickname} />;
  }
  return (
    <WaitingRoom
      gameState={gameState}
      playerId={playerId}
      onStart={onStart}
      onLeave={onLeave}
      roomCode={roomCode}
    />
  );
}
