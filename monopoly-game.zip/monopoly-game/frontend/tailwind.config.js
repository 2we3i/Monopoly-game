/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Deep felt-green table the board sits on - evokes a physical
        // tabletop rather than a generic app background.
        table: {
          DEFAULT: '#0f3d2e',
          dark: '#0a2b20',
          light: '#155040',
        },
        // Parchment board surface
        board: {
          DEFAULT: '#f2e8d5',
          tile: '#faf4e6',
          line: '#d9c9a3',
        },
        ink: {
          DEFAULT: '#1f2417',
          soft: '#4a4f3d',
          faint: '#8a8b76',
        },
        brass: {
          DEFAULT: '#c9982f',
          deep: '#96701c',
          light: '#e3bb5c',
        },
        rent: {
          DEFAULT: '#a8342a',
          deep: '#7c2019',
        },
        go: {
          DEFAULT: '#1f7a5c',
          deep: '#155a43',
        },
        // Property group colors - original palette, not Hasbro's exact hues
        grp: {
          brown: '#7a5230',
          lightblue: '#a3d0e8',
          pink: '#d888b0',
          orange: '#e08a3c',
          red: '#c4453a',
          yellow: '#e8cf4a',
          green: '#3f9463',
          blue: '#3a6ea8',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        tile: '0 1px 2px rgba(31,36,23,0.15)',
        panel: '0 8px 30px rgba(0,0,0,0.35)',
        token: '0 2px 4px rgba(0,0,0,0.4)',
        brass: '0 0 0 3px rgba(201,152,47,0.35)',
      },
      keyframes: {
        'dice-tumble': {
          '0%': { transform: 'rotate(0deg) scale(1)' },
          '25%': { transform: 'rotate(120deg) scale(1.08)' },
          '50%': { transform: 'rotate(240deg) scale(0.96)' },
          '75%': { transform: 'rotate(330deg) scale(1.04)' },
          '100%': { transform: 'rotate(360deg) scale(1)' },
        },
        'token-hop': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
        'pop-in': {
          '0%': { transform: 'scale(0.85)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        'coin-fall': {
          '0%': { transform: 'translateY(-12px)', opacity: '0' },
          '30%': { opacity: '1' },
          '100%': { transform: 'translateY(0)', opacity: '0' },
        },
      },
      animation: {
        'dice-tumble': 'dice-tumble 0.5s ease-out',
        'token-hop': 'token-hop 0.35s ease-in-out',
        'pop-in': 'pop-in 0.2s ease-out',
        'coin-fall': 'coin-fall 0.9s ease-out forwards',
      },
    },
  },
  plugins: [],
};
